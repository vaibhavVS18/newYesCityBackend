import mongoose from "mongoose";

const { Schema } = mongoose;

const miscellaneousSchema = new Schema({
  cityId: { type: Schema.Types.ObjectId, ref: "City", required: true },
  cityName: { type: String },

  engagement: {
    views: { type: Number, default: 0 },
    viewedBy: [{ type: Schema.Types.ObjectId, ref: "User" }]
  },

  reviews: [{ type: Schema.Types.ObjectId, ref: "Review" }],

  localMap: { type: String },
  emergencyContacts: { type: String },
  hospitalsPolice: { type: String },
  locationLink: { type: String },

  lat: { type: Number },
  lon: { type: Number },


  parking: { type: String },
  publicWashrooms: { type: String },

  premium: {
    type: String,
    enum: ["FREE", "A", "B"],
    default: "FREE"
  }
});

const Miscellaneous =
  mongoose.models.Miscellaneous ||
  mongoose.model("Miscellaneous", miscellaneousSchema);

export default Miscellaneous;
