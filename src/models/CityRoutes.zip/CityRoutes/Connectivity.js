import mongoose from "mongoose";

const { Schema } = mongoose;

const connectivitySchema = new Schema({
  cityId: { type: Schema.Types.ObjectId, ref: 'City', required: true },
  cityName: { type: String },

  engagement: {
    views: { type: Number, default: 0 },
    viewedBy: [{ type: Schema.Types.ObjectId, ref: "User" }]
  },

  reviews: [{ type: Schema.Types.ObjectId, ref: 'Review' }],

  nearestAirportStationBusStand: { type: String, required: true },
  distance: { type: String, required: true },

  lat: { type: Number, required: true },
  lon: { type: Number, required: true },

  locationLink: { type: String, required: true },
  majorFlightsTrainsBuses: { type: String },

  premium: {
    type: String,
    enum: ["FREE", "A", "B"],
    default: "FREE"
  },
});

const Connectivity =
  mongoose.models.Connectivity || mongoose.model("Connectivity", connectivitySchema);

export default Connectivity;
